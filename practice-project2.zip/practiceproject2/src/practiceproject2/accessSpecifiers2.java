package practiceproject2;


	class priaccessspecifier 
	{ 
	} 

	public class accessSpecifiers2 {

		public static void main(String[] args) {
			//private
			System.out.println("Private Access Specifier");

		}

}
