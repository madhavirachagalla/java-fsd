package practiceproject2;

public class accessSpecifiers4 {

	public void display()
	{
		System.out.println("This is public access specifier");
	}
	
	public static void main(String[] args) {
		accessSpecifiers4 obj = new accessSpecifiers4();
		obj.display();
	}
	}

