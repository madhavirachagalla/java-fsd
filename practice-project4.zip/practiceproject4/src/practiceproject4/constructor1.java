package practiceproject4;

	public class constructor1{


		public static void main(String[] args) {

			Std std1=new Std(15,"Rina");
			Std std2=new Std(10,"Sandy");
			std1.display();
			std2.display();
				}
		}


